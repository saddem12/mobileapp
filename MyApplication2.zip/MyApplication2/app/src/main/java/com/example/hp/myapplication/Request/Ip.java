package com.example.hp.myapplication.Request;


public class Ip {
    private String ip = "http://192.168.1.100/android_connect/";
    public String getIp() {
        return ip;
    }
}
